import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-install-prerequisites',
  templateUrl: './install-prerequisites.component.html',
  styleUrls: ['./install-prerequisites.component.css']
})
export class InstallPrerequisitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
