import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docker-container-logs',
  templateUrl: './docker-container-logs.component.html',
  styleUrls: ['./docker-container-logs.component.css']
})
export class DockerContainerLogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
