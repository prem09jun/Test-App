import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-swagger-api',
  templateUrl: './custom-swagger-api.component.html',
  styleUrls: ['./custom-swagger-api.component.css']
})
export class CustomSwaggerApiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
