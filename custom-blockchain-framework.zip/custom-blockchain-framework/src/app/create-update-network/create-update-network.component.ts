import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-update-network',
  templateUrl: './create-update-network.component.html',
  styleUrls: ['./create-update-network.component.css']
})
export class CreateUpdateNetworkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
